#include <stdio.h>
main()

{
   int i;
   i = 2;
   
   while( i<25)
     {
        printf("%d\n", i);
         i += 2;
     }
}
