#include <stdio.h>
main()
{ int n;
  printf("enter the number\n");
  scanf("%d",&n);
  if(n%2==0)
  {
    printf("entered number is even\n");
  }
  else
   printf("entered number is odd\n");
} 
