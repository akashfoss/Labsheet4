#include <stdio.h>
main()
{
  int n,i;
  float sum=0;
  printf("enter n\n");
  scanf("%d",&n);
  for(i=1;i<=n;i++)
   { 
     sum=(sum+(1/i));
   }
  printf("sum of series=%f\n",sum);
}
