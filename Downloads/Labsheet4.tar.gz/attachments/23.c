#include <stdio.h>
main()
{ int n,i;
  printf("enter the year\n");
  scanf("%d",&n);
  for(i=n;i<=2100;i++)
   {  
      if(i%4==0)
       {  
           printf("%d is a leap year\n",i);
       }
    }
}
          
            
        
