#include <stdio.h>
main()
{ int n;
  printf("enter the number\n");
  scanf("%d",&n);
  if(n>0)
   { 
     printf("entered number is positive\n");
   } 
  else if(n<0)
   {
     printf("entered number is negative\n");
   }
  else
    printf("entered number is 0\n");
}  
  
