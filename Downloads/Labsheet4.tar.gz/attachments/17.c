#include <stdio.h>
#include <math.h>
main()

{
  int i,n,sum;
  sum = 0;
  printf("enter the number\n");
  scanf("%d", &n);

  for(i=1 ; i<=n ; i++)
    {
       sum = sum + pow(i,2);
    }
       printf("sum of squares of given numbers = %d\n", sum);
    

}
