#include <stdio.h>
main()
{ int bonus;
  float salary;
  char c;
  printf("enter gender\n");
  c=getchar();
  printf("enter the salary\n");
  scanf("%f",&salary);
  
  if(c=='m')
   { 
      if(salary<10000)
       { bonus=7;  
         salary=(float)(salary+(salary*7/100)); 
       } 
      else  
       { bonus=5;
         salary=(float)(salary+(salary*5/100));
       }
   }
   else if(c=='f')
    { 
       if(salary<10000)
       { bonus=12;  
         salary=(float)(salary+(salary*12/100));  
       } 
      else  
       { bonus=10;
         salary=(float)(salary+(salary*10/100)); 
       }
     
    }
   printf("bonus=%d,salary=%f\n",bonus,salary);
}
