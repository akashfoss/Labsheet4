#include <stdio.h>
main()
 
{
   int i,n,sum;
   printf("enter the number\n");
   scanf("%d", &n);
   sum = 0;
   i = 1;
  
   do
    {
      sum = sum +i;
      i++;
    }
    
    while (i<=n);
    printf("sum of numbers = %d\n", sum);
}
   
