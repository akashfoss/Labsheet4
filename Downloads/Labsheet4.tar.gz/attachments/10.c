#include <stdio.h>
main()
{ char c;
  printf("enter the character\n");
  c=getchar();
  switch(c)
  { case 'a':printf("%c is a vowel",c);break;
    case 'e':printf("%c is a vowel",c);break;
    case 'i':printf("%c is a vowel",c);break;
    case 'o':printf("%c is a vowel",c);break;
    case 'u':printf("%c is a vowel",c);break;
    case 'A':printf("%c is a vowel",c);break;
    case 'I':printf("%c is a vowel",c);break;
    case 'E':printf("%c is a vowel",c);break;
    case 'O':printf("%c is a vowel",c);break;
    case 'U':printf("%c is a vowel",c);break;
    default :printf("%c is not a vowel\n",c);
  }
}
