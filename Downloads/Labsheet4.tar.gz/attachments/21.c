#include <stdio.h>
main()

{
  int i,n;
  
  printf("enter a number\n");
  scanf("%d", &n);

  for(i=1 ; i<=n ; i++);
   {
      n = n*i;
      printf("factorial of given number = %d\n", n);
   }

}
