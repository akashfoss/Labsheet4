#include <stdio.h>
main()

{
  int a,i;
  printf("enter a number\n");
  scanf("%d", &a);
  
  for(i=1 ; i<=a ; i=i+2)
   {
     printf("%d\n", i);
   }

}
