#include <stdio.h>
main()
{ char d;
  int hrs,pk;
  printf("enter vehicle type(c,b,s)\n");
  d=getchar();
  printf("enter numbner of hours\n");
  scanf("%d",&hrs);
  if(d=='c')
   {
     pk=50*hrs;
   }
  else if(d=='b')
   {
     pk=25*hrs;
   }
  else
   {
     pk=10*hrs;
   }
  printf("parking charge is %d\n",pk);
} 
