#include <stdio.h>
main()
{ int a,b,c,sum=0;
  float avg;
  printf("enter first number\n");
  scanf("%d",&a);
  printf("enter second number\n");
  scanf("%d",&b);
  printf("enter third number\n");
  scanf("%d",&c);
  sum=a+b+c;
  if(sum>100 && sum<200)
    {
      printf("sum is in the allowed range \n");
    }
  else
    {
      printf("sum has the exceeded range\n");
    }
  avg=(float)(sum/3);
  printf("sum=%d,average=%f\n",sum,avg);
}
