#include <stdio.h>
#include <math.h>
main()
{ int x,i,c;
  printf("enter the number\n");
  scanf("%d",&x);
  printf("enter the exponential factor\n");
  scanf("%d",&i);
  c= pow(x,i);
  printf("desired result is %d\n",c);
}
