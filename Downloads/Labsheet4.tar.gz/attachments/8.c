#include <stdio.h>
main()
{ int n,count;
  printf("enter the marks\n");
  scanf("%d",&n);
  if(n>=95 && n<=100)
   { 
    printf("grade=a+\n");
    count=1;
   }
   else if(n>=90 && n<=94)
   { 
    printf("grade=a\n");
    count=2;
   }
   else if(n>=80 && n<=89)
   { 
    printf("grade=b+\n");
    count=3;
   } 
   else if(n>=75 && n<=59)
   { 
    printf("grade=b\n");
    count=4;
   } 
    else if(n>=70 && n<=74)
   { 
    printf("grade=c+\n");
    count=5;
   }
   else if(n>=60 && n<=69)
   { 
    printf("grade=c\n");
    count=6;
   } 
    else if(n>=50 && n<=59)
   { 
    printf("grade=d\n");
    count=7;
   } 
    else if(n>=40 && n<=49)
   { 
    printf("grade=p\n");
    count=8;
   }
    else 
   { 
    printf("grade=f\n");
    count=9;
   }
    printf("count=%d\n",count);
}
