#include <stdio.h>
main()
{ int a,b,c,d,sum=0,avg;
  printf("enter the marks of one suject\n");
  scanf("%d",&a);
  printf("enter the marks of 2nd suject\n");
  scanf("%d",&b);
  printf("enter the marks of 3rd suject\n");
  scanf("%d",&c);
  printf("enter the marks of 4th suject\n");
  scanf("%d",&d);
  sum=a+b+c+d;
  avg=sum/4;
  printf("sum=%d,average=%d",sum,avg);
}
  
