#include <stdio.h>
main()

{
  int n,i,pro;
  printf("enter number\n");
  scanf("%d", &n);

  for(i=1 ; i<=10 ; i++)
   {
     pro = n*i;
     printf("%d*%d=%d\n", n,i,pro);
   }

}
