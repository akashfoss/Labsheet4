#include <stdio.h>
void fib( int );
main()
{
	int n, i, f;  	
	printf( "Enter n: " );
	scanf( "%d", &n );	
	fib( n ); 
}
void fib( int n )
{
	int a = 0, b = 1, c, d, i, x;
	for ( i = 1; i <= n; i++ )
	{
		c = a + b;
		a = b;
		b = c;
		d = a + b;
		for( x = c + 1; x < d; x++ ) //checking for numbers between c and d
		{
			if( x <= n )
				printf( "\n%d\n", x );
			else
				break;
		}
	}
}