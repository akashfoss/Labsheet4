#include <stdio.h>
int greatestNo( int, int, int );
main()
{
	int a, b, c, g;
	printf( "Enter three numbers: " );
	scanf( "%d %d %d", &a, &b, &c );
	g = greatestNo( a, b, c );
	printf( "The largest number is: %d", g );
}
int greatestNo( int a, int b, int c )
{
	if( a > b && a > c )
		return a;
	else if( b > a && b >c )
		return b;
	else
		return c;
}