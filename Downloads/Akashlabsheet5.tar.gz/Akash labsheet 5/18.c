#include <stdio.h>
int largeNumber( int );
main()
{
	int n, lno;
	printf( "Enter a number:" );
	scanf( "%d", &n );
	lno = largeNumber( n );
	printf( "The largest digit in %d is: %d", n, lno );
}
int largeNumber( int n )
{
	int lno, last;
	lno = n % 10;
	while( n > 0 )
	{
		last = n % 10;
		if( last > lno )
			lno = last;
		n = n/10;
	}
	return lno;
}