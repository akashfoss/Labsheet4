#include <stdio.h>
int fact( int );
main()
{
	int n, f;
	printf( "Enter a number: " );
	scanf( "%d", &n );
	f = fact( n );
	printf( "The factorial is: %d", f );
}
int fact( int n )
{
	int f;
	if ( n == 1 )
		return 1;
	else
		return n * fact( n - 1 );
}