#include <stdio.h>
void fib( int );
main()
{
	int n;
	printf( "Enter n: " );
	scanf( "%d", &n );
	fib( n );
}
void fib( int n )
{
	int a = 0, b = 1, c, i;
	for ( i = 1; i <= n; i++ )
	{
		printf( "\n%d\n", a );
		c = a + b;
		a = b;
		b = c;
	}
}