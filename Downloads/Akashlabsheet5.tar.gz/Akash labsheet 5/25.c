#include <stdio.h>
#include <math.h>
float sumSeries( int );
int fact( int );
main()
{
	int n;
	float sum;
	printf( "Enter n: " );
	scanf( "%d", &n );
	sum = sumSeries( n );
	printf( "The sum is: %.2f", sum );
}
float sumSeries( int n )
{
	int i;
	float sum = 0;
	for( i = 1; i <=n; i++ )
	{
		sum = sum + (pow( i, i ))/fact(i);
	}
	return sum;
}
int fact( int n )
{
	int f = 1, i;
	for( i = 1; i <= n; i++ )
	{
		f = f * i;
	}
	return f;
}