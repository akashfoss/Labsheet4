#include <stdio.h>
int fib( int );
main()
{
	int n, res;
	printf( "Enter n: " );
	scanf( "%d", &n );
	res = fib( n );
	printf( "The nth term is: %d", res );
}
int fib( int n )
{
	if( n == 1 )
		return 0;
	else if( n == 2 )
		return 1;
	else 
		return (fib( n-1 ) + fib( n-2 ));
		
}