#include <stdio.h>
int conv( int );
main()
{
	int dec, bin;
	printf( "Enter a decimal number: " );
	scanf( "%d", &dec );
	bin = conv( dec );
	printf( "The binary equivalent is: %d", bin );
}
int conv( int dec )
{
	static int rem, m = 1, bin; 
	if( dec != 0 )
	{
		rem = dec % 2;
		bin = bin + rem * m;
		m = m * 10;
		conv( dec/2 );
	}
	return bin;
}