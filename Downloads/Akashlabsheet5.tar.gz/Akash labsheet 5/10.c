#include <stdio.h>
float conv( float );
main()
{
	float cel, far;
	printf( "Enter the temperature(in C): " );
	scanf( "%f", &cel );
	far = conv( cel );
	printf( "\n The temperature in Fahrenheit is: %f", far );
}
float conv( float cel )
{
	float far;
	far = cel * 1.8 + 32;
	return far;
}