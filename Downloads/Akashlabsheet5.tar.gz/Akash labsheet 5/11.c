#include <stdio.h>
#include <math.h>
float calc( float, float, int, int );
main()
{
	int n = 12, t;
	float r, p, a;
	printf( "Enter the principal amount, rate of interest, and no of years: " );
	scanf( "%f %f %d", &p, &r, &t );
	a = calc( p, r, t, n );
	printf( "The annual compound interest is: %.2f", a );
}
float calc( float p, float r, int t, int n )
{
	int a;
	a = p*pow((1 + (r/n)), n*t );
	return a;
} 