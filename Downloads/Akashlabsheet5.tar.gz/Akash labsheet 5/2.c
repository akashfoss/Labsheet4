#include <stdio.h>
void reverse( int );
main()
{
	int n, rev;
	printf( "Enter a number between 100 and 9999: " );
	scanf( "%d", &n );
	if( n < 100 && n > 9999 )
		{
			printf( "Invalid no! Enter a number between 100 and 9999: " );
			scanf( "%d", &n );
		}
	reverse( n );
}
void reverse( int n )
{
	while( n > 0 )
		{
			printf( "\n%d\n", n%10 );
			n = n/10;
		}

}
