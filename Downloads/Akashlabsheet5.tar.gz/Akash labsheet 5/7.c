#include <stdio.h>
main()
{
	int n, k = 1, a = 1, b = 2, c = 3, d, i;
	printf( "Enter n: " );
	scanf( "%d", &n );
	for( i = 1; i <= n && k <= n; i++, k++ )
	{
		if( k <= 3 )
		{
			printf( " %d ", k );
			//k++;
		}
		else if( k > 3 )
		{
			d = b + 2 * a;
			a = b;
			b = c;
			c = d;
			printf( " %d ", d );
			//k++;
		}
	}
}