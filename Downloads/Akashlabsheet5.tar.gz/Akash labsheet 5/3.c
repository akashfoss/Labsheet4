#include <stdio.h>
void calc( int, int ); 
main()
{
	int ch, n, count, price, c1 = 0, c2 = 0, c3 = 0, c4 = 0;
	char cont = 'Y';
	float amt;
	do
	{
	printf( "\nSlno\tChocolate type\tPrice(Rs.)\tDiscount\n" );
	printf( "1\tWhite Chocolate\t\t50\t10\n2\tDark Chocolate\t\t60\t12\n3\tRaw Chocolate\t\t42\t6\n4\tBittersweet Chocolate\t55\t8\n" );
	printf( "\nSelect a chocolate type and the number of chocolates: " );
	scanf( "%d %d", &ch, &n );
	switch( ch )
		{
			case 1: price = 50 * n;
				amt = price - price * 0.1;
				c1++;
				break;
			case 2: price = 60 * n;
				amt = price - price * 0.12;
				c2++;
				break;
			case 3: price = 42 * n;
				amt = price - price * 0.06;
				c3++;
				break;
			case 4: price = 55 * n;
				amt = price - price * 0.08;
				c4++;
				break;
			default: printf( "Invalid selection!" );
		}
	printf( "\nThe total amount is: %.2f\n", amt );
	printf( "\nDo you want to continue?" );
	scanf( "%c", &cont );
//	calc( ch, n );
	}while( cont == 'Y' || cont == 'y' );
	printf("\nTotal number of White Chocolates sold is: %d\n, Dark Chocolates sold is: %d\n, Raw Chocolates sold is: %d\n and Bittersweet Chocolates sold is: %d\n", c1, c2, c3, c4 );
}
//void calc( int ch, n )
//{
//	int price, amt, c1=c2=c3=c4=0;



//} 
