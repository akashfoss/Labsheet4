#include <stdio.h>
int abs(int arg)
{
	if( arg > 0 )
		return -arg;
	else
		return arg;
}
main()
{
	int inval;
	printf( "Enter an integer: " );
	scanf( "%d", &inval );
	printf( "Absolute value is: %d\n", abs(inval));
}