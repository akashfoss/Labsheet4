#include <stdio.h>
int add( int, int );
int diff( int, int );
int prod( int, int );
float div( int, int );
main()
{
	int a, b, ch;
	float res;
	printf( "Enter two numbers: " );
	scanf( "%d %d", &a, &b );
	printf( "Select one:\n1. Add\n2. Difference\n3. Product\n4. Division\n" );
	scanf( "%d", &ch );
	switch( ch )
	{
		case 1: res = add( a, b );
				break;
		case 2: res = diff( a, b );
				break;
		case 3: res = prod( a, b );
				break;
		case 4: res = div( a, b );
				break;	
		default: printf( "\nInvalid choice!\n" );
	}
	printf( "\n The result is: %.2f", res );
}
int add( int a, int b )
{
	int res;
	res = a + b;
	return res;
}
int diff( int a, int b )
{
	int res;
	res = a - b;
	return res;
}
int prod( int a, int b )
{
	int res;
	res = a * b;
	return res;
}
float div( int a, int b )
{
	float res;
	res = (float)a/b;
	return res;
}

