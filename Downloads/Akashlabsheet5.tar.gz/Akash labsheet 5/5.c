#include <stdio.h>
int fact( int );
main()
{
	int i, n, copy, last, res = 0, f = 0;
	printf( "Enter a number: " );
	scanf( "%d", &n );	
	//copy = n;
	for( i = 0; i <= n; i++ )
	{ 
	copy = i;
	res = 0;
	
	while( copy > 0 )
	{
		last = copy % 10;
		f = fact(last);
		res = res + f;
		copy = copy / 10;


	}
	if( res == i )  
	printf( "%d\n", res );
	}
}
int fact( int l )
{
	int f = 1, i = 1;
	while( i <= l )
	{
		f = f * i;
		i++;
	}
	//printf( "f is %d\n", f );
	return f;
} 
