#include <stdio.h>
#define PI 3.14
void areaCircle();
void periCircle();
void areaRect();
void periRect();
main()
{
	int ch;
	printf( "\n1. Area of a circle\n2. Perimeter of a circle\n3. Area of a rectangle\n4. Perimeter of a rectangle\n\nChoose one:" );
	scanf( "%d", &ch );
	switch( ch )
	{
		case 1: areaCircle();
				break;
		case 2: periCircle();
				break;
		case 3: areaRect();
				break;
		case 4: periRect();
				break;	
		default: printf( "Invalid choice!" );			
	}
}
void areaCircle()
{
	int r;
	float a;
	printf( "Enter the radius: " );
	scanf( "%d", &r );
	a = PI * r * r;
	printf( " The area is: %f", a );
}
void periCircle()
{
	int r;
	float p;
	printf( "Enter the radius: " );
	scanf( "%d", &r );
	p = 2 * PI * r;
	printf( "The perimeter is: %f", p );
}
void areaRect()
{
	int l, b, a;
	printf( "Enter the length and breadth: " );
	scanf( "%d %d", &l, &b );
	a = l * b;
	printf( "The area is: %d", a );
}
void periRect()
{
	int l, b, p;
	printf( "Enter the length and breadth: " );
	scanf( "%d %d", &l, &b );
	p = 2*(l+b);
	printf( "The perimeter is: %d", p );
}