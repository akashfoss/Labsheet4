#include <stdio.h>
int factorial( int );
main()
{
	int n, fact;
	printf( "Enter a number: " );
	scanf( "%d", &n );
	fact = factorial( n );
	printf( "The factorial is: %d", fact );
}
int factorial( int n )
{
	int f = 1, i;
	for( i = 1; i <= n; i++ )
	{
		f = f * i;
	}
	return f;
}