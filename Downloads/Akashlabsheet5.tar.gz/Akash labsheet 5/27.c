#include <stdio.h>
int greatestCD( int, int );
main()
{
	int a, b, gcd;
	printf( "Enter two numbers: " );
	scanf( "%d %d", &a, &b );
	gcd = greatestCD( a, b );
	printf( "The greatest common divisor is: %d", gcd );
}
int greatestCD( int a, int b )
{
	if( a % b == 0)
		return b;
	else
		return greatestCD( b, a%b );
}