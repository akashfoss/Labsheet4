#include <stdio.h>
float power( float, int );
main()
{
	float x, res;
	int y;
	printf( "Enter the base, x and exponent, y: " );
	scanf( "%f %d", &x, &y );
	res = power( x, y);
	printf( "The result is: %.2f", res );
}
float power( float x, int y )
{
	if( y == 0)
		return 1;
	else if( y == 1 )
		return x;
	y--;
	return x * power( x, y);
}