#include <stdio.h>
int abs(int arg)
{
	if( arg > 0 )
		return -arg;
	else
		return arg;
}
main()
{
	float flval;
	printf( "Enter an integer: " );
	scanf( "%f", &flval );
	printf( "Absolute value is: %d\n", abs(flval));
}