#include <stdio.h>
float val( int );
main()
{
	int y, t = -9;
	y = val(t);
}
float val( int t )
{
	int y;
	while( t <= 9 )
		{
			if( t < 0 )
				y = ( 3 * t * t ) + 5;
			else
				y = -(3 * t * t ) + 5;	
			printf( "\nWhen t = %d, y = %d \n", t, y );
			t += 3;
		
		}  
}
