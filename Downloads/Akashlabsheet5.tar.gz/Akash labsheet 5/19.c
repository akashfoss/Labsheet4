#include <stdio.h>
int sumSeries( int );
main()
{
	int n, sum;
	printf( "Enter n: " );
	scanf( "%d", &n );
	sum = sumSeries( n );
	printf( "The sum of 1+2+3+...+n is: %d", sum );
}
int sumSeries( int n )
{
	int sum = 0, i;
	for( i = 1; i <= n; i++ )
	{
		sum = sum + i;
	}
	return sum;
}