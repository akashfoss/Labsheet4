#include <stdio.h>
int prod( int, int );
main()
{
	int a, b, res;
	printf( "Enter two numbers: " );
	scanf( "%d %d", &a, &b );
	res = prod( a, b );
	printf( "The product is: %d", res ); 
}
int prod( int a, int b )
{
	if( b == 1 )
		return a;
	return a + prod( a, b - 1 );
}