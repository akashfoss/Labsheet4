#include <stdio.h>
int power( int, int );
main()
{
	int x, y, res;
	printf( "Enter the base and exponent: " );
	scanf( "%d %d", &x, &y );
	res = power( x, y );
	printf( "The result is: %d", res);
}
int power( int x, int y )
{
	if( y == 0 )
		return 1;
	else if( y == 1 )
		return x;
	return x * power( x, y-1 );
}